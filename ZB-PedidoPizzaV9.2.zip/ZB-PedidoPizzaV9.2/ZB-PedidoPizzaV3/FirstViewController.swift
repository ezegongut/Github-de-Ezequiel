//
//  FirstViewController.swift
//  ZB-PedidoPizzaV3
//
//  Created by Ezequiel Gonzalez on 10/05/2016.
//  Copyright © 2016 AppNovedosas. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {

  //  @IBOutlet weak var size: UITextField!
    
    @IBOutlet weak var verResultado: UILabel!
    
    @IBOutlet weak var avanza: UILabel!
    
  override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
       
       // let sigVista=segue.destinationViewController as! vistaConfirmacio_n
     //   sigVista.tamanoSeleccionado = verResultado
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func small(sender: AnyObject) {
        verResultado.text="Tamaño small"
    }
    
    @IBAction func middle(sender: AnyObject) {
        verResultado.text="Tamaño Mediana"
    }
    
    @IBAction func big(sender: AnyObject) {
        verResultado.text="Tamaño Grande"
    }
    
    
    
    
/*
    @IBAction func validarSize(sender: AnyObject) {
        
        let sizeLocal:Int? = Int(self.size.text!)!
        switch sizeLocal!
        {
        case 1: verResultado.text = "Pizza Chica"
        avanza.text = "Avanza al paso 2 de 4"
        case 2: verResultado.text = "Pizza Mediana"
         avanza.text = "Avanza al paso 2 de 4"
        case 3: verResultado.text = "Pizza Grande"
         avanza.text = "Avanza  al paso 2 de 4"
        default: verResultado.text = "No es correcta tu selección"
         avanza.text = "No debes avanzar, revisa tu selección"
        
        }
 
        
    }
    */
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

