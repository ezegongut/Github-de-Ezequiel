//
//  VistaQueso.swift
//  ZB-PedidoPizzaV3
//
//  Created by Ezequiel Gonzalez on 11/05/2016.
//  Copyright © 2016 AppNovedosas. All rights reserved.
//

import UIKit

class VistaQueso: UIViewController {

    @IBOutlet weak var queso: UITextField!
    
    @IBOutlet weak var verResultado: UILabel!
    
    @IBOutlet weak var avanza: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    
    @IBAction func validarQueso(sender: AnyObject) {
        let quesoLocal:Int? = Int(self.queso.text!)!
        
        switch quesoLocal!
        {
        case 1: verResultado.text = "Queso Mozarela"
            avanza.text = "Super..! avanza al paso 3 de 4"
        case 2: verResultado.text = "Queso Cheddar"
            avanza.text = "Excelente, avanza al paso 2 de 4"
        case 3: verResultado.text = "Queso Parmesano"
            avanza.text = "OK, avanza al paso 2 de 4"
        default: verResultado.text = "No es correcta tu selección"
            avanza.text = "No debes avanzar. revisa tu seleccion"
        }
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
