//
//  vistaConfirmación.swift
//  ZB-PedidoPizzaV3
//
//  Created by Ezequiel Gonzalez on 11/05/2016.
//  Copyright © 2016 AppNovedosas. All rights reserved.
//

import UIKit

class vistaConfirmacio_n: UIViewController {

    var tamanoSeleccionado = 0
    @IBOutlet weak var tamañoMasa: UILabel!
    
    override func viewWillAppear(animated: Bool) {
        tamañoMasa.text=String(tamanoSeleccionado)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
