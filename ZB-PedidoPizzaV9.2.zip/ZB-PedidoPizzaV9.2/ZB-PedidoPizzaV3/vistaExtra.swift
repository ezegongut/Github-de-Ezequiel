//
//  vistaExtra.swift
//  ZB-PedidoPizzaV3
//
//  Created by Ezequiel Gonzalez on 11/05/2016.
//  Copyright © 2016 AppNovedosas. All rights reserved.
//

import UIKit

class vistaExtra: UIViewController {
    
    @IBOutlet weak var extra: UITextField!

    @IBOutlet weak var verResultado: UILabel!
    
    @IBOutlet weak var avanza: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    
    @IBAction func validaExtra(sender: AnyObject) {
    
        let extraLocal:Int? = Int(self.extra.text!)!
        switch extraLocal!
        {
        case 1: verResultado.text = "Jamón"
            avanza.text = "Avanza a la confirmacion"
        case 2: verResultado.text = "Pepperoni"
            avanza.text = "Avanza a la confirmacion"
        case 3: verResultado.text = "Salchicha"
            avanza.text = "Avanza a la confirmacion"
        case 4: verResultado.text = "Pavo"
            avanza.text = "Avanza a la confirmacion"
        case 5: verResultado.text = "Aceitunas"
            avanza.text = "Avanza a la confirmacion"
        case 6: verResultado.text = "Cebolla"
            avanza.text = "Avanza a la confirmacion"
        default: verResultado.text = "No es correcta tu selección"
            avanza.text = "No Avanzar, revisa tu selección"
        }
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
     
     {
     let extraLocal:Int? = Int(self.extra.text!)!
     switch extraLocal!
     {
     case 1: verResultado.text = "Jamón"
     case 2: verResultado.text = "Pepperoni"
     case 3: verResultado.text = "Salchicha"
     case 4: verResultado.text = "Pavo"
     case 5: verResultado.text = "Aceitunas"
     case 6: verResultado.text = "Cebolla"
     default: verResultado.text = "No es correcta tu selección"
     }
     
     }

     
     
     
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
