//
//  SecondViewController.swift
//  ZB-PedidoPizzaV3
//
//  Created by Ezequiel Gonzalez on 10/05/2016.
//  Copyright © 2016 AppNovedosas. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    
    @IBOutlet weak var tipoMasa: UITextField!

    @IBOutlet weak var confirmacion: UILabel!
    
    @IBOutlet weak var avanza: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func validarMasa(sender: AnyObject) {
        let masaLocal:Int? = Int(self.tipoMasa.text!)!
        switch masaLocal!
        {
        case 1: confirmacion.text = "Masa Delgada"
            avanza.text = "Super, Avanza al Paso 3 de 4"
        case 2: confirmacion.text = "Masa Crujiente"
            avanza.text = "Excelente Avanza al Paso 3 de 4"
        case 3: confirmacion.text = "Masa Delgada"
            avanza.text = "Bien, Avanza al Paso 3 de 4"
        default: confirmacion.text = "No es correcta tu selección"
            avanza.text = "NO debes avanzar, revisa tu selección"
        }
       
           }
    
    
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

