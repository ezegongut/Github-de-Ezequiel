//
//  ViewConfirmacion.swift
//  ZF-PIZZA-CAM-PANTA
//
//  Created by Ezequiel Gonzalez on 22/05/2016.
//  Copyright © 2016 AppNovedosas. All rights reserved.
//

import UIKit

//PASO FINAL

class ViewConfirmacion: UIViewController {

    var tamanofinal:String?
    @IBOutlet weak var TamPizza: UILabel!
    override func viewWillAppear(animated: Bool) {
    TamPizza.text=String(tamanofinal)
    }
    
    @IBOutlet weak var masaFinal: UILabel!
    
    var quesoF:String?
    @IBOutlet weak var quesoFinal: UILabel!
    override func viewDidAppear(animated: Bool) {
        quesoFinal.text=String(quesoF)
    }
    var extraF:String?
    @IBOutlet weak var extraFinal: UILabel!
   
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
