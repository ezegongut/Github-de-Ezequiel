//
//  ViewExtras.swift
//  ZF-PIZZA-CAM-PANTA
//
//  Created by Ezequiel Gonzalez on 22/05/2016.
//  Copyright © 2016 AppNovedosas. All rights reserved.
//

import UIKit

//PASO 4
class ViewExtras: UIViewController {
    
    

    // **** VISUALIZACION DE VISTAS ANTERIORES *** TQueso.text=String(Tipque)
  
    var tp : String?
    @IBOutlet weak var TamPiz: UILabel!
    override func viewWillAppear(animated: Bool) {
        TamPiz.text=String(tp)
    }

    var msa:String?
   @IBOutlet weak var TipMas: UILabel!
   // override func viewDidAppear(animated: Bool) {
     //   TipMas.text=String(msa)
   // }
 
    var Tipque:String?
   @IBOutlet weak var TQueso: UILabel!
    override func viewDidAppear(animated: Bool) {
        TQueso.text=String(Tipque)
    }

     // *** PREPARACION DE VISTAS AL PASO FINAL ***
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?)
    {
        let vistaConfirmacion=segue.destinationViewController as! ViewConfirmacion
        
        vistaConfirmacion.tamanofinal=tp //Variable Destino de este paso
      //  vistaConfirmacion.masaFinal=msa  //
       vistaConfirmacion.quesoF=Tipque // cambio de variable, la variable "TamanoPizz" lleva el contenido de "tamanoPizza" del paso 1
        vistaConfirmacion.extraF=extra.text!
    }

    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBOutlet weak var extra: UILabel!
    
    
    @IBAction func cebolla(sender: AnyObject) {
        extra.text="Cebolla"    }
    
    @IBAction func peperoni(sender: AnyObject) {
    extra.text="Peperoni" }
    
    @IBAction func jamon(sender: AnyObject) {
    extra.text="Jamón" }

    @IBAction func salchicha(sender: AnyObject) {
    extra.text="Salchicha" }
    
    @IBAction func hongos(sender: AnyObject) {
    extra.text="Hongos" }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
