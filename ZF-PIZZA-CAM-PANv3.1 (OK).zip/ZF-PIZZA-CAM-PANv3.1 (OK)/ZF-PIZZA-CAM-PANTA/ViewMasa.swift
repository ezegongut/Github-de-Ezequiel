//
//  ViewMasa.swift
//  ZF-PIZZA-CAM-PANTA
//
//  Created by Ezequiel Gonzalez on 22/05/2016.
//  Copyright © 2016 AppNovedosas. All rights reserved.
//

import UIKit

// PASO 2

class ViewMasa: UIViewController {

   
    @IBOutlet weak var masa: UILabel!
    
    
    //*** RECEPCIÓN DE TAMAÑO DE PASO 1
    var tamanoPizza:String?  // Se cacha la variable destino del paso 1
    @IBOutlet weak var TamPizza: UILabel!  //etiqueta en Destino
    override func viewWillAppear(animated: Bool)
    {
        TamPizza.text=String(tamanoPizza) //Se muestra en la caja de texto "TamPizza" lo que viene del paso 1 en la variable "tamanoPizza"
    }

    
    
    // ***** DATOS PARA ENVIO DE PASO 2 MASA --> PASO 3 TIPO DE QUESO
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?)
    {
        let vistaQueso=segue.destinationViewController as! ViewQueso
        vistaQueso.TipoQueso=masa.text!  //Variable Destino de este paso
        vistaQueso.TamanoPizz=tamanoPizza! // cambio de variable, la variable "TamanoPizz" lleva el contenido de "tamanoPizza" del paso 1
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    
    
    // SELECCION DE MASA
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func delgada(sender: AnyObject) {
       masa.text="Masa Delgada"
    }
    
    @IBAction func crujiente(sender: AnyObject) {
         masa.text="Masa Crujiente"
    }
   
    @IBAction func gruesa(sender: AnyObject) {
         masa.text="Masa Gruesa"
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
