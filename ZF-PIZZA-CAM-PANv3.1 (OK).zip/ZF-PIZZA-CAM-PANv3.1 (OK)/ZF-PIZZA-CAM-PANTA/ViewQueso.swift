//
//  ViewQueso.swift
//  ZF-PIZZA-CAM-PANTA
//
//  Created by Ezequiel Gonzalez on 22/05/2016.
//  Copyright © 2016 AppNovedosas. All rights reserved.
//

import UIKit

// PASO 3
class ViewQueso: UIViewController {
    
 // **** VISUALIZACION DE VISTAS ANTERIORES ***
    
    // PASO 1 --> PASO 2--> SE MUESTRA AQUÍ
    var TamanoPizz:String? //Recepcion de variable de paso 2 que contiene "tamanoPizza" de paso 1
    @IBOutlet weak var TamPizza: UILabel!
    override func viewWillAppear(animated: Bool) {
        TamPizza.text=String(TamanoPizz) //muestra seleccion de paso 1
    }
    
    
    var TipoQueso:String? //Recepcion de variable de paso 2
    @IBOutlet weak var TipQueso: UILabel!
    override func viewDidAppear(animated: Bool) {
        TipQueso.text=String(TipoQueso) //muestra seleccion de paso 2
    }

    // *** PREPARACION DE VISTAS AL PASO 4 ***
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?)
    {
        let vistaIngredientes=segue.destinationViewController as! ViewExtras
        vistaIngredientes.Tipque=seleccionQueso.text //Variable Destino de este paso
       vistaIngredientes.msa=TipQueso.text!  //
    vistaIngredientes.tp=TamanoPizz! // cambio de variable, la variable "TamanoPizz" lleva el contenido de "tamanoPizza" del paso 1
    }
    
    
    // Seleccion del tipo de queso
   
    @IBOutlet weak var seleccionQueso: UILabel!
    
    
    @IBAction func cheddar(sender: AnyObject) {
        seleccionQueso.text="Queso Cheddar"
    }
    
    @IBAction func mozarella(sender: AnyObject) {
         seleccionQueso.text="Queso Mozarella"
    }

    @IBAction func parmesano(sender: AnyObject) {
         seleccionQueso.text="Queso Parmesano"
    }
    
    @IBAction func sinQueso(sender: AnyObject) {
         seleccionQueso.text="Sin Queso"
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
